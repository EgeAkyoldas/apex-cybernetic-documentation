# Architecture Document: Project Frontier (C4 Model)

## 1. System Overview
Project Frontier is a distributed, high-performance 3D engine environment delivered via the browser. The architecture is designed to decouple heavy simulation logic (Physics/AI/ECS) from the rendering and UI layers to ensure a consistent 60 FPS "Native-feel" as mandated by the **PRD**.

## 2. Level 1: System Context Diagram
The System Context shows how Project Frontier interacts with external actors and services.

```text
+-----------------+       +--------------------------+       +-------------------+
|                 |       |    Project Frontier      |       |                   |
|   End User      | <---> |    (Web Application)     | <---> |   Supabase BaaS   |
| (KBM / Gamepad) |       |  High-fidelity 3D Game   |       | (Auth, Saves, DB) |
+-----------------+       +--------------------------+       +-------------------+
                                    |
                                    v
                          +--------------------------+
                          |   Cloudflare R2 / CDN    |
                          | (GLB, KTX2, Asset Bundles)|
                          +--------------------------+
```

## 3. Level 2: Container Diagram
The Container level breaks down the Web Application into its high-level technical boundaries.

```text
+---------------------------------------------------------------------------------------+
| Web Browser (Client)                                                                  |
|                                                                                       |
|  +-----------------------+       +------------------------+       +----------------+  |
|  |    UI Container       |       |   Simulation Core      |       |  Asset Worker  |  |
|  | (React / Tailwind)    | <---> | (bitecs ECS / Rapier)  | <---> | (Web Worker)   |  |
|  | Handles HUD & Menus   |       | High-frequency Logic   |       | Draco/KTX2 Dec |  |
|  +-----------------------+       +------------------------+       +----------------+  |
|              ^                           |                                            |
|              |                           v                                            |
|              |               +------------------------+                               |
|              +-------------> |   Rendering Engine     |                               |
|                              | (Three.js / R3F)       |                               |
|                              +------------------------+                               |
+---------------------------------------------------------------------------------------+
```

## 4. Level 3: Component Breakdown (Simulation Core)
This level details the internal logic of the "Simulation Core" container, which is the heart of the **Design Document's** Hybrid ECS.

- **ECS World (bitecs):** Manages all game entities (Player, Horse, NPCs, Projectiles). Data is stored in `SharedArrayBuffers` for zero-copy access where possible.
- **Physics Engine (Rapier.js WASM):** Executes the rigid body dynamics for the **Equine System** and combat collisions.
- **System Pipeline:**
    - `InputSystem`: Maps raw events to ECS components.
    - `MovementSystem`: Processes kinematic and dynamic motion.
    - `CollisionSystem`: Handles raycasting for bullets and terrain alignment.
    - `SyncSystem`: The "Bridge" that pushes ECS `Transform` data to Three.js `Object3D` refs.

## 5. Data Architecture
As established in the **Tech Spec 3.1**, data is tiered based on access frequency:
- **Hot Data (Frame-by-Frame):** Stored in `bitecs` TypedArrays (f32/u8). This includes position, velocity, and health.
- **Warm Data (Session-based):** Stored in **Zustand** stores. Includes UI state, active weapon ID, and inventory counts.
- **Cold Data (Persistent):** Stored in **Supabase (PostgreSQL)**. Includes the player's world coordinates, flags, and progression (per **Tech Spec 3.2**).

## 6. API Layer Design
The architecture utilizes a "Thick Client" approach. The API layer (Supabase) is used primarily for:
- **State Synchronization:** Initializing the ECS world from a saved JSON blob.
- **Asset Manifests:** Fetching signed URLs for the **Chunk Manager** to download `.glb` files from Cloudflare R2.
- **Edge Functions:** Handling sensitive logic like leaderboard validation or multiplayer handshake (future-proofing).

## 7. Authentication & Authorization
- **Provider:** Supabase Auth (JWT-based).
- **Flow:** User signs in via a UI modal -> JWT is stored in memory -> All subsequent requests to the Save/Load API include the `Authorization: Bearer` header.
- **Row Level Security (RLS):** Enabled on the `saves` table to ensure players can only `SELECT/UPDATE` their own game state.

## 8. Scalability Strategy
- **Asset Scalability:** Using **Cloudflare R2** with a global CDN ensures that the **100x100m chunks** defined in the **Tech Spec** are delivered with sub-50ms latency regardless of user location.
- **Compute Scalability:** By offloading asset decoding (Draco/KTX2) to **Web Workers**, we scale horizontally across CPU cores, preventing the main thread from choking during world traversal.
- **Memory Scalability:** The **Chunk Manager** implements an LRU (Least Recently Used) cache for VRAM, purging textures and geometries as defined in the **Tech Spec 7**.

## 9. Monitoring & Observability
- **Client-side Telemetry:** Sentry integration for catching WebGL context losses or WASM memory leaks.
- **Performance Profiling:** Custom `Stats.js` integration in dev builds to track:
    - `MS`: Frame time (Target < 16.6ms).
    - `MB`: Heap memory usage.
    - `DRW`: Draw call count (Target < 500).

## 10. Deployment Architecture
- **CI/CD:** GitHub Actions triggers a **Vite** build.
- **Environment:**
    - **Production:** Vercel Edge Network.
    - **Assets:** Cloudflare R2 (Global CDN).
    - **Database:** Supabase (AWS us-east-1).

## 11. Security Architecture
- **Input Sanitization:** As noted in the **PRD**, all movement vectors are validated in the ECS system to prevent speed-hacking.
- **CORS Policy:** Cloudflare R2 buckets are restricted to the production domain.
- **Content Security Policy (CSP):** Strict policies to allow only WASM execution from trusted sources (Rapier) and data from Supabase.
- **SharedArrayBuffer Security:** Mandatory COOP/COEP header configuration (`same-origin` / `require-corp`) to enable high-performance memory sharing between the main thread and simulation workers.