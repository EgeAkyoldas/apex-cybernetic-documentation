# Project Roadmap: Project Frontier

## 1. Executive Summary
Project Frontier is a 20-week development initiative aimed at delivering a high-fidelity, browser-based 3D Western experience. The roadmap is divided into five primary stages, moving from core engine architecture to a global production launch. Success is defined by achieving 60 FPS performance and a <5MB initial bundle size as established in the **PRD**.

## 2. Vision & Strategic Goals
- **Browser AAA:** Prove that high-end open-world mechanics (horse physics, time-dilation) can exist without native installation.
- **Performance First:** Maintain a strict frame budget (16.6ms) from day one.
- **Seamless Exploration:** Implement the **Tech Spec 2.1** chunking system to allow infinite world traversal.

## 3. Phase Breakdown

### Phase 1: Foundation & Core Simulation (Weeks 1-4)
*Focus: Establishing the Hybrid ECS and Physics Bridge.*
- **Objective:** Get a character moving in a physics-enabled empty void.
- **Key Tasks:** ECS setup, Rapier.js integration, and the "Bypass-Render" bridge.
- **Bundle Audit:** Initial tree-shaking and bundle-size monitoring (Addressing **CRIT-001**).

### Phase 2: The Living World (Weeks 5-8)
*Focus: Environment, Chunking, and World Persistence.*
- **Objective:** Implement seamless world streaming and the Floating Origin system.
- **Key Tasks:** Chunk Manager, Asset Manifest integration (**WARN-002**), and Day/Night cycle.

### Phase 3: The Frontier Experience (Weeks 9-12)
*Focus: Equine Systems and Character FSMs.*
- **Objective:** High-fidelity horse riding and mounting mechanics.
- **Key Tasks:** Horse RigidBody, Terrain alignment, and Spring-arm camera.

### Phase 4: Combat & Dead-Eye (Weeks 13-16)
*Focus: Tactical gunplay and Time Dilation.*
- **Objective:** Functional shooting mechanics and the "Dead-Eye" visual sequence.
- **Key Tasks:** Projectile system, GSAP TimeScale lerping, and UI HUD (Survival Cores).

### Phase 5: Persistence, AI & Launch (Weeks 17-20)
*Focus: Backend integration, NPC logic, and Optimization.*
- **Objective:** Save/Load functionality, NPC behaviors, and final VRAM/Bundle optimization.
- **Key Tasks:** Supabase integration, AI FSMs, and Production Deployment.

## 4. Milestone Definitions
| Milestone | Name | Criteria | Week |
| :--- | :--- | :--- | :--- |
| **M1** | **Engine Heartbeat** | ECS/Physics syncing at 60Hz with < 5MB bundle. | 4 |
| **M2** | **Infinite Horizon** | Chunking system loading/unloading without frame drops. | 8 |
| **M3** | **Mounted Combat** | Player can mount horse, ride, and fire weapons. | 13 |
| **M4** | **Technical Alpha** | Full gameplay loop (Save/Load + Combat + World). | 17 |
| **M5** | **Production Ready** | All assets optimized (KTX2/Draco); < 1.5GB VRAM usage. | 20 |

## 5. Sprint Planning (2-Week Sprints)
- **Sprint 1-2:** Infrastructure, ECS schemas, and Rapier WASM loading.
- **Sprint 3-4:** Character controller and "Survival Cores" UI foundation.
- **Sprint 5-6:** Chunk Manager, Web Worker pipeline, and Asset Manifest.
- **Sprint 7-8:** Horse physics, procedural alignment, and mounting logic.
- **Sprint 9-10:** Combat mechanics, Dead-Eye post-processing, and SFX integration.

## 6. Dependencies & Critical Path
1. **WASM Loading (Critical):** Physics must initialize before the ECS world.
2. **Asset Pipeline:** KTX2/Draco compression must be finalized before Phase 2 testing.
3. **Floating Origin:** Must be functional before world size exceeds 5000 units.

## 7. Resource Requirements
- **Frontend Engineer:** Expertise in Three.js and ECS patterns.
- **Physics/Math Lead:** Focus on Rapier.js and kinematic controllers.
- **Technical Artist:** Blender to GLB/KTX2 pipeline management.
- **Backend/DevOps:** Supabase configuration and Cloudflare R2 CDN setup.

## 8. Risk Register
| Risk | Severity | Mitigation |
| :--- | :--- | :--- |
| **Bundle Size (>5MB)** | **High** | Dynamic imports for XState/Rapier; strict asset hashing. |
| **VRAM Overflow** | Medium | LRU Cache in Chunk Manager (per **Tech Spec 7**). |
| **Physics Jitter** | Medium | Floating Origin system (per **Tech Spec 2.1**). |
| **WebGL Context Loss** | Low | Persistence of ECS state in LocalStorage for recovery. |

## 9. Success Metrics per Phase
- **Foundation:** < 2ms Logic update time.
- **World:** < 500ms chunk decode time in Web Worker.
- **Gameplay:** 0% jitter during Horse-to-Ground transitions.
- **Launch:** 60 FPS on mid-range hardware; < 5MB initial JS bundle.