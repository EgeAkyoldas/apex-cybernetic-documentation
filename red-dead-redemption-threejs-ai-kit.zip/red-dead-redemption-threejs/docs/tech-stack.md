# Tech Stack Specification: Project Frontier

## 1. Executive Summary
Project Frontier utilizes a "Web-Native AAA" stack designed for high-throughput 3D rendering and low-latency physics. To satisfy the **PRD's** constraint of a <5MB initial bundle while delivering an open-world experience, we are prioritizing tree-shakable libraries, WASM-based physics, and GPU-accelerated texture compression.

## 2. Frontend Stack
### 2.1 Core Engine & Rendering
- **Three.js:** The primary 3D engine as established in the **PRD**.
- **React Three Fiber (R3F):** Acts as the **View Layer**. It provides a declarative bridge to Three.js but is optimized to avoid re-renders for high-frequency transform updates by using direct Ref manipulation.
- **React Three Drei:** A helper library for R3F to implement essential utilities like `PerspectiveCamera` (for the Spring Arm logic) and `Html` overlays.
- **WebGPU (Experimental) / WebGL 2.0:** Utilizing Three.js `WebGPURenderer` where available, falling back to WebGL 2.0 to ensure the "Native-feel" performance.

### 2.2 State Management & Logic
- **bitecs:** A high-performance, ultra-fast **ECS library** using TypedArrays. Handles the core game simulation (Entity transforms, AI states, Combat logic) to ensure 60Hz stability.
- **Zustand:** Used for transient UI state and global game settings. It allows the ECS simulation to push updates to the UI without React overhead.
- **XState:** To implement the **Finite State Machines (FSM)** defined in the **Design Document** for Player and Horse behaviors (`MOUNTING`, `GALLOP`, etc.). **Note:** Loaded via dynamic imports in the entry point to optimize initial bundle size (CRIT-001).
- **GSAP (GreenSock):** As mandated by the **PRD**, used for UI transitions and the "Dead-Eye" time-dilation visual curves.

### 2.3 UI & Styling
- **Tailwind CSS:** For rapid, low-footprint HUD development.
- **Lucide React:** For minimalist, vector-based iconography in the Radial Menu.

### 2.4 Audio Engine
- **Howler.js:** Selected for robust spatial audio support and the ability to handle independent time-scale pitch shifting for the Dead-Eye mechanic (WARN-003).

## 3. Backend & Persistence
- **Supabase (PostgreSQL + Auth):** Handles the **PRD P2** requirement for Save/Load functionality and player persistence.
- **Vercel Edge Functions:** For low-latency API calls related to world state or leaderboard data.

## 4. Physics & Math
- **Rapier.js (WASM):** As established in the **PRD**, providing high-performance rigid body dynamics for the **Equine System** and the Projectile Simulation System. **Note:** Loaded via dynamic imports in the entry point to optimize initial bundle size (CRIT-001).
- **Three-Mesh-BVH:** To accelerate raycasting against complex world geometry (essential for the "Chunk Manager" to detect ground height quickly).

## 5. Asset Pipeline & Storage
- **Format:** GLTF 2.0 (Binary `.glb`).
- **Compression:**
  - **Draco:** For mesh geometry compression.
  - **KTX2 / Basis Universal:** For GPU-native texture compression (as per **PRD Constraints**).
- **Storage:** AWS S3 or Cloudflare R2 with a global CDN to facilitate the **Design Document's** worker-based chunk loading.

## 6. Infrastructure & Deployment
- **Build Tool:** **Vite**. Provides the fastest HMR (Hot Module Replacement) for 3D development and efficient tree-shaking for the 5MB bundle limit.
- **Hosting:** Vercel or Netlify for automated CI/CD and edge caching. **Requirement:** Mandatory COOP (`same-origin`) and COEP (`require-corp`) headers must be configured to enable `SharedArrayBuffer` support for ECS/WASM.
- **CI/CD Pipeline:** Includes a mandatory **Bundle Size Budget** step to enforce the <5MB constraint (CRIT-001).
- **Web Workers:** Custom implementation for the **Chunk Manager** to decode assets off the main thread.

## 7. Decision Log & Rationale

| Technology | Rationale | Reference |
| :--- | :--- | :--- |
| **Vite** | Essential for managing the complex asset dependency graph while keeping the dev loop fast. | PRD Constraints |
| **bitecs** | Provides the performance of a native ECS (Entity-Component-System) by using TypedArrays, bypassing React's reconciliation for the 60Hz game loop. | Design Doc 4.1 |
| **Zustand** | Allows the "Logic Update" loop in the **Design Document** to modify state at 60Hz without triggering React component tree reconciliations. | Design Doc Section 2 |
| **XState** | Provides a visual, testable way to manage the complex transitions between human and horse states. | Design Doc Section 6 |
| **Howler.js** | Superior control over audio sprites and pitch-shifting compared to native Three.Audio, critical for Dead-Eye effects. | WARN-003 |
| **Three-Mesh-BVH** | Standard Three.js raycasting is too slow for an open world; BVH allows for "Triple-A" collision detection. | PRD P0 (Combat) |

## 8. Alternatives Considered
- **PlayCanvas:** *Rejected.* While powerful, it is a proprietary editor-first engine. Three.js/R3F allows for better integration with the modern React ecosystem and custom shader control.
- **Cannon.js / Ammo.js:** *Rejected.* Cannon is unmaintained; Ammo is too heavy. Rapier.js offers the best performance-to-size ratio via WASM.
- **Redux:** *Rejected.* Too much boilerplate and performance overhead for a frame-based game loop.

## 9. Development Tooling
- **Blender:** Primary 3D modeling and animation tool.
- **GLTF-Pipeline:** For command-line asset optimization.
- **Three.js Inspector:** For real-time scene debugging.
- **Rapier Debug Renderer:** For visualizing physics colliders during development.