# Technical Specification: Project Frontier

## 1. Overview
This Technical Specification defines the implementation details for Project Frontier, a browser-based open-world western. It builds upon the **Hybrid ECS** architecture and **Rapier.js** physics integration established in the **Design Document** and **Tech Stack**.

## 2. Detailed Feature Specifications

### 2.1. World Streaming & Chunk Manager
To support the **PRD's** open-world requirement without crashing browser memory, the world is partitioned into a grid.
- **Chunk Dimensions:** 100m x 100m.
- **Loading Radius:** 3x3 grid (9 chunks) active around the player.
- **Logic:** 
  - As the player crosses a chunk boundary, the `ChunkManager` calculates the new 3x3 grid.
  - New chunks are initialized via `Web Workers` to decode **KTX2** textures and **Draco** meshes.
  - Out-of-bounds chunks are marked for `dispose()` to clear VRAM.
- **Floating Origin:** When `|x| or |z| > 5000`, the `WorldShift` system subtracts the current position from all active entities and the physics world to prevent 32-bit float jitter.

### 2.2. Equine System (Horse Physics)
- **Physics Body:** A Rapier.js `Dynamic` RigidBody with a capsule collider.
- **Ground Alignment:** Four raycasts (one per hoof) detect terrain normals. The horse mesh `up` vector is interpolated to the average normal for realistic traversal on inclines.
- **Mounting Logic:** 
  1. Distance check (< 2m).
  2. Transition Player FSM to `MOUNTING`.
  3. Parent Player mesh to Horse "Saddle" Bone.
  4. Disable Player capsule physics; Horse RigidBody now receives input.

### 2.3. Dead-Eye Mechanic (Time Dilation)
- **Implementation:** A global `gameState.timeScale` variable (default `1.0`).
- **Activation:** On trigger, `timeScale` lerps to `0.2` over 200ms using **GSAP**.
- **Physics Sync:** Rapier.js `world.step()` is called with `fixedDeltaTime * timeScale`.
- **Visuals:** A post-processing shader pass applies a sepia-toned LUT and radial blur, as specified in the **Design Document**.

### 2.4. Bridge System (UI Data Binding)
To resolve UI-to-ECS latency and performance bottlenecks (WARN-001):
- **Function:** A specialized ECS system that monitors specific `Stats` and `Transform` components.
- **Frequency:** Standardized 20Hz update loop to ensure predictable data propagation and alignment with AI logic.
- **Operation:** Copies raw TypedArray data from **bitecs** into the **Zustand** `SurvivalStore`. This ensures the UI remains reactive without the overhead of 60Hz React reconciliations.

### 2.5. Audio System
- **Engine:** Howler.js integrated via an `AudioSystem` (WARN-003).
- **Spatial Audio:** Updates listener position and orientation based on the active camera's `Object3D` every frame.
- **Time-Scale Sync:** The system monitors `gameState.timeScale`. When Dead-Eye is active, it applies a real-time pitch-shift and low-pass filter to all active global sounds to simulate time dilation.

## 3. Data Models & Schemas

### 3.1. ECS Component Schema (bitecs)
Simulation data is stored in `TypedArrays` for maximum cache efficiency.

| Component | Properties (Type) | Description |
| :--- | :--- | :--- |
| **Transform** | `x, y, z, rx, ry, rz` (f32) | Position and Rotation. |
| **Velocity** | `vx, vy, vz` (f32) | Linear velocity for physics interpolation. |
| **Stats** | `health, stamina, deadEye` (f32) | Core player/NPC vitals. |
| **ActorState**| `stateEnum` (u8) | Maps to XState machine IDs (Idle, Run, etc.). |
| **Inventory** | `weaponActive` (u8), `ammo` (u16) | Current equipment state. |

### 3.2. Save Game Schema (JSON)
Persisted to **Supabase** as established in the **Tech Stack**. Updated to version 1.1 to include Equine and Environmental state.
```json
{
  "version": "1.1",
  "player_id": "uuid",
  "timestamp": "ISO-8601",
  "world_state": {
    "position": [x, y, z],
    "rotation": [y],
    "origin_offset": [ox, oy, oz],
    "world_time": 14.5, 
    "active_weather": "clear"
  },
  "stats": { 
    "hp": 100, 
    "stamina": 85, 
    "deadeye_meter": 50 
  },
  "horse_state": {
    "spawned": true,
    "position": [hx, hy, hz],
    "is_mounted": false,
    "stamina": 100
  },
  "inventory": [
    { "id": "revolver_01", "ammo": 12, "equipped": true },
    { "id": "repeater_01", "ammo": 30, "equipped": false }
  ],
  "flags": { 
    "tutorial_complete": true,
    "current_bounty": 0
  }
}
```

## 4. API & Integration (Supabase)
| Method | Path | Description |
| :--- | :--- | :--- |
| `POST` | `/rest/v1/saves` | Upsert current player state. |
| `GET` | `/rest/v1/saves?select=*` | Retrieve latest save on login. |
| `GET` | `/rest/v1/assets_manifest` | Fetch CDN URLs for chunk-specific GLB files. |

## 5. Business Logic Rules
1. **Projectile Simulation System:** Projectiles are not hitscan. They are entities with a `Velocity` component. Each frame, a raycast is performed between `pos(t)` and `pos(t+1)` to detect collisions.
2. **Stamina Depletion:** Galloping reduces `Stats.stamina` by 5 units/sec. At 0, the Horse FSM forces a transition to `TROT`.
3. **AI Aggro:** NPCs within a 20m radius of a `GunfireEvent` transition their FSM to `COMBAT` or `FLEE` based on their `Bravery` stat.

## 6. Validation Rules
- **Input Sanitization:** All movement vectors from the client are normalized to prevent "speed hacking" (vector length > 1.0).
- **Asset Integrity:** GLB files must pass a checksum validation before being parsed by the `GLTFLoader` to prevent malicious code injection via custom shaders.

## 7. Error Handling
- **OOM (Out of Memory):** If VRAM exceeds 80% of the browser's reported limit, the `ChunkManager` aggressively purges all chunks except the one the player is currently occupying.
- **Physics Explosion:** If a RigidBody velocity exceeds `1000 units/s`, the entity is reset to the last "Grounded" position to prevent falling through the map.

## 8. Performance Requirements
- **Frame Budget:** 16.6ms total.
  - **Logic/Physics (WASM):** < 4ms.
  - **React/Zustand UI:** < 2ms.
  - **Render (Three.js):** < 10ms.
- **Draw Calls:** Max 500 per frame (optimized via InstancedMesh for foliage/rocks).
- **VRAM Limit:** < 1.5GB total texture/geometry footprint.

## 9. Testing Strategy
- **Unit Testing:** Vitest for ECS system logic (e.g., health subtraction, movement math).
- **Integration Testing:** Playwright to simulate user "Mounting" and "Shooting" flows in a headless Chromium instance.
- **Performance Profiling:** Chrome DevTools "Performance" tab to monitor Main Thread jank during chunk transitions.
- **Physics Debugging:** Enable `RapierDebugRenderer` in dev builds to visualize colliders and contact points.