# Project Frontier: Master Implementation Task List (v2.0)

## Phase 1: Project Foundation & Core Infrastructure
- [ ] **Environment Setup & Optimization (Addressing CRIT-001)**
  - [ ] Initialize Vite project with TypeScript and React
  - [ ] Configure Tailwind CSS and Frontier Design Tokens (per UI Design 11)
  - [ ] Set up `vite-plugin-bundle-visualizer` for continuous bundle audit
  - [ ] Implement dynamic import wrappers for `rapier.js` and `xstate` to keep initial bundle < 5MB
- [ ] **Core Engine Integration**
  - [ ] Install and configure Three.js, R3F, and Drei
  - [ ] Initialize **bitecs** ECS world and TypedArrays (per Tech Spec 3.1)
  - [ ] Set up **Rapier.js** WASM physics worker (Off-main-thread initialization)
- [ ] **The "Bridge" Architecture**
  - [ ] Implement the `useFrame` game loop to drive ECS systems
  - [ ] Create the `SyncTransform` system to map ECS data to R3F Refs (Bypass-Render)
  - [ ] Develop the `TimeScale` controller for global time dilation (per Tech Spec 2.3)

## Phase 2: World Streaming & Environmental Systems
- [ ] **Asset Manifest & Metadata (Addressing WARN-002)**
  - [ ] Define JSON schema for `/rest/v1/assets_manifest` (Chunk ID -> CDN URL mapping)
  - [ ] Create internal `ManifestParser` to handle pre-fetching logic
- [ ] **Chunk Manager Implementation**
  - [ ] Develop `GridPartition` logic for 100m x 100m sectors
  - [ ] Implement `ProximityLoader` for 3x3 active grid management
  - [ ] Build Web Worker pipeline for Draco/KTX2 asset decoding
- [ ] **Floating Origin System**
  - [ ] Implement `WorldShift` logic for the 5000-unit threshold (per Tech Spec 2.1)
  - [ ] Create coordinate translation layer for physics vs. rendering
- [ ] **Environment Rendering**
  - [ ] Integrate `Three-Mesh-BVH` for fast terrain raycasting
  - [ ] Implement `InstancedMesh` system for foliage and rocks
  - [ ] Set up dynamic Day/Night cycle with atmospheric scattering

## Phase 3: Character & Equine Controllers
- [ ] **Player Controller (XState Integration)**
  - [ ] Build Player FSM (IDLE, SPRINT, AIM, MOUNTING)
  - [ ] Implement kinematic character controller with Rapier.js
  - [ ] Set up Animation Mixer with cross-fading for skeletal meshes
- [ ] **Equine System (Horse Physics)**
  - [ ] Create Horse RigidBody with "Floating Capsule" logic
  - [ ] Implement "Four-Hoof" terrain alignment raycasting (per Tech Spec 2.2)
  - [ ] Develop the Mounting/Dismounting animation and parenting logic
- [ ] **Camera System**
  - [ ] Build "Spring Arm" camera with collision avoidance
  - [ ] Implement cinematic framing transitions for combat/riding

## Phase 4: Combat & Dead-Eye Mechanics
- [ ] **Weapon System (Addressing INFO-001)**
  - [ ] Implement Projectile Entity system (Manual raycast-per-frame logic)
  - [ ] Create `GunfireEvent` dispatcher for AI aggro (per Tech Spec 5)
  - [ ] Build weapon recoil and muzzle flash effects
- [ ] **Dead-Eye Implementation**
  - [ ] Implement GSAP `timeScale` lerping logic
  - [ ] Create Target Marking system (Red "X" markers with white glow)
  - [ ] Develop the post-processing pipeline (Sepia LUT + Radial Blur)

## Phase 5: UI & UX Development
- [ ] **Survival Cores HUD (Addressing WARN-001)**
  - [ ] Build "Survival Cores" circular progress rings (Health, Stamina, Dead-Eye)
  - [ ] Map ECS `Stats` component data to Zustand `SurvivalStore`
  - [ ] Implement pulse effect via GSAP when a core is depleted
- [ ] **Interaction Systems**
  - [ ] Develop the **Radial Weapon Menu** with GSAP animations
  - [ ] Implement contextual 3D prompts (R3F Html) for "Mount" / "Loot"
- [ ] **Dialogue & Narrative UI**
  - [ ] Build cinematic letterboxed dialogue box
  - [ ] Implement Typewriter effect and branching choice UI

## Phase 6: AI & NPC Lifecycle
- [ ] **NPC Architecture**
  - [ ] Implement throttled 20Hz AI update loop (per Design Doc 4.5)
  - [ ] Create FSM for "Wander", "Flee", and "Combat" states
- [ ] **Crowd/Wildlife Management**
  - [ ] Develop chunk-based population density maps
  - [ ] Implement basic pathfinding (NavMesh) for NPCs

## Phase 7: Backend & Persistence
- [ ] **Supabase Integration**
  - [ ] Configure Auth and PostgreSQL schema (per Tech Spec 3.2)
  - [ ] Implement `Save/Load` service for player state persistence
- [ ] **Asset Management**
  - [ ] Set up Cloudflare R2/S3 bucket for GLB/KTX2 storage
  - [ ] Implement asset manifest fetching and checksum validation

## Phase 8: Optimization & Quality Assurance
- [ ] **Performance Profiling**
  - [ ] Audit VRAM usage (Target < 1.5GB)
  - [ ] Optimize draw calls (Target < 500) via occlusion culling
- [ ] **Testing**
  - [ ] Write Vitest unit tests for ECS math and FSM transitions
  - [ ] Set up Playwright integration tests for critical user flows
- [ ] **Compatibility**
  - [ ] Implement tiered graphics settings (Low/Med/Ultra)
  - [ ] Test WebGL 2.0 fallback for non-WebGPU browsers

## Phase 9: Deployment & Launch
- [ ] **Build Pipeline**
  - [ ] Configure Vite for tree-shaking and asset hashing
  - [ ] Final verification of < 5MB initial bundle constraint
- [ ] **Deployment**
  - [ ] Deploy to Vercel with Edge Function configuration
  - [ ] Set up monitoring and error tracking (Sentry)