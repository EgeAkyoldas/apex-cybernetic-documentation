# UI/UX Design Specification: Project Frontier

## 1. Design Philosophy & Visual Language: "The Modern Frontier"
The UI is designed to stay out of the player's way, favoring immersion over information density.
- **Diegetic Integration:** UI elements should feel like they belong to the world (e.g., parchment textures, weathered metals).
- **Transient Presence:** HUD elements fade out when not in combat or low on resources to maximize the 3D vista.
- **Kinetic Feedback:** Every interaction uses **GSAP** for weighted, organic transitions that mimic physical movement.

## 2. Brand Identity
- **Logo:** High-contrast, slab-serif typography with a distressed "stamped" effect.
- **Tone:** Rugged, atmospheric, and prestigious.

## 3. Color System
Based on the **Tech Spec's** data models for health, stamina, and dead-eye.

| Role | Hex Code | Usage |
| :--- | :--- | :--- |
| **Primary (Ochre)** | `#D4AF37` | Stamina, active selections, gold-tier items. |
| **Secondary (Blood)** | `#8B0000` | Health, damage indicators, critical warnings. |
| **Accent (Dead-Eye)** | `#FF8C00` | Dead-Eye meter, target markers. |
| **Background (Charcoal)** | `#1A1A1A` | Radial menu backing, dark mode UI containers. |
| **Surface (Parchment)** | `#F5F5DC` | Dialogue boxes, maps, inventory backgrounds. |
| **Text (Lead)** | `#E0E0E0` | Primary body text for high readability. |

## 4. Typography Scale
- **Headings (Slab Serif):** *Arvo* or *Playfair Display* (for a Western feel).
- **Body & Data (Sans Serif):** *Inter* (for maximum legibility at small sizes on 1080p displays).
- **Monospace:** *JetBrains Mono* (for ammo counts and technical readouts).

## 5. Component Library

### 5.1. The "Survival Cores" (HUD)
Circular progress rings located at the bottom left.
- **Outer Ring:** Current resource level (Health/Stamina).
- **Inner Core:** Regeneration rate/status.
- **Animation:** Pulse effect via GSAP when a core is depleted.

### 5.2. The Radial Weapon Menu
As established in **PRD P1** and **Design Document 3**.
- **Structure:** 8-slot circular overlay centered on screen.
- **Interaction:** `TAB` (Hold) to open; Mouse/Joystick direction to select.
- **Visuals:** Blurred background (via CSS `backdrop-filter`) with 2D SVG icons from **Lucide React**.

### 5.3. Cinematic Dialogue Box
- **Position:** Bottom center.
- **Style:** Letterboxed (black bars top/bottom).
- **Animation:** Typewriter effect for text.

## 6. Screen Layouts & Key Views

### 6.1. Main Gameplay HUD (Minimalist)
```text
+-------------------------------------------------------------+
|                                                             |
|                                                             |
|                                          [ Ammo: 06 / 30 ]  |
|                                          [ Weapon: Revolver]|
|                                                             |
|                                                             |
|                                                             |
|                                                             |
|  [ Compass / Mini-map ]                                     |
|  ( ) ( ) ( ) <--- Survival Cores (HP, Stamina, Dead-Eye)    |
+-------------------------------------------------------------+
```

### 6.2. Weapon Wheel Overlay (Active)
```text
+-------------------------------------------------------------+
|                  [ WEAPON SELECTION ]                       |
|                           ^                                 |
|                     /     |     \                           |
|            [Unarmed] <--- ( ) ---> [Repeater]               |
|                     \     |     /                           |
|                           v                                 |
|                    [ Schofield Rev ]                        |
+-------------------------------------------------------------+
```

## 7. Interaction Patterns
- **Dead-Eye Transition:** On activation, the UI scales up by 5%, and a sepia filter (`feColorMatrix`) is applied to the SVG filter chain over the entire viewport.
- **Mounting Prompt:** A contextual "Hold [E] to Mount" prompt appears near the Horse's saddle bone using **R3F Html** components.

## 8. User Flow: The "Dead-Eye" Sequence
1. **Input:** Player holds `Right Click` (Aim) + `Middle Mouse` (Dead-Eye).
2. **Logic:** `gameState.timeScale` drops to 0.2 (**Tech Spec 2.3**).
3. **UI Visual:** Screen edges vignette; sound desaturates.
4. **Interaction:** Player hovers over NPCs; red "X" markers appear on hitboxes.
5. **Execution:** Player clicks `Left Fire`; time snaps back to 1.0; animations play at 3x speed.

## 9. Responsive Breakpoints
- **Desktop (Ultra-wide):** HUD elements pushed to 5% margin.
- **Desktop (1080p):** Standard layout.
- **Tablet/Mobile:** Survival cores move to top-left; touch-friendly joystick overlay for movement.

## 10. Accessibility (WCAG 2.1 AA)
- **High Contrast Mode:** Swaps Ochre/Parchment for pure White/Black.
- **Subtitles:** Toggleable background opacity for dialogue.
- **Visual Aid:** Red "X" markers in Dead-Eye include a secondary "white glow" for color-blind users.

## 11. Design Tokens (Tailwind Config)
```javascript
module.exports = {
  theme: {
    extend: {
      colors: {
        'frontier-gold': '#D4AF37',
        'frontier-blood': '#8B0000',
        'frontier-dead-eye': '#FF8C00',
        'frontier-parchment': '#F5F5DC',
      },
      fontFamily: {
        western: ['Arvo', 'serif'],
        ui: ['Inter', 'sans-serif'],
      }
    }
  }
}
```