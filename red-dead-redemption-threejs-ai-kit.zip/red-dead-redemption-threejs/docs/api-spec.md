# API Specification: Project Frontier

## 1. Overview
This document defines the RESTful endpoints and data schemas for Project Frontier's backend services, primarily hosted on Supabase and Cloudflare R2.

## 2. Authentication
All requests to protected endpoints must include a JWT in the Authorization header.
- **Header:** `Authorization: Bearer <JWT>`
- **Provider:** Supabase Auth.

## 3. Asset Management API

### 3.1. Fetch Asset Manifest
Retrieves the mapping of world chunks to their respective asset bundles (WARN-002).

- **Endpoint:** `GET /rest/v1/assets_manifest`
- **Response Schema:**
```json
[
  {
    "chunkId": "string (e.g., '10_12')",
    "bounds": {
      "min": [number, number],
      "max": [number, number]
    },
    "assets": {
      "terrain": "string (CDN URL to .glb)",
      "foliage": "string (CDN URL to .glb)",
      "props": "string (CDN URL to .glb)",
      "textures": "string (CDN URL to .ktx2)"
    },
    "checksum": "string (SHA-256)"
  }
]
```

## 4. Persistence API

### 4.1. Save Game State
Persists the current player progress.

- **Endpoint:** `POST /rest/v1/saves`
- **Body:** See **Tech Spec 3.2** (Save Game Schema).

### 4.2. Load Game State
Retrieves the most recent save for the authenticated user.

- **Endpoint:** `GET /rest/v1/saves?select=*&order=created_at.desc&limit=1`

## 5. Telemetry & Logging

### 5.1. Performance Telemetry
Used for alpha testing to monitor engine performance across different hardware.

- **Endpoint:** `POST /rest/v1/telemetry`
- **Body:**
```json
{
  "fps_avg": "number",
  "vram_usage_mb": "number",
  "draw_calls_avg": "number",
  "gpu_info": "string",
  "browser": "string"
}
```