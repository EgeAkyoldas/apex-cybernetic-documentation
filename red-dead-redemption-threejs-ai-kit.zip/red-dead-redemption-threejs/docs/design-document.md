# Design Document: Project Frontier (RDR Three.js Clone)

## 1. Overview & Purpose
Project Frontier is a high-fidelity 3D western adventure executed in the browser. Building upon the **PRD**, this document outlines the architectural patterns and design decisions required to implement complex systems like the Equine System, World Streaming, and the Dead-Eye mechanic using Three.js and Rapier.js.

## 2. System Context Diagram
The system operates entirely within the client-side browser environment, leveraging hardware acceleration.

```
[ User Input (KBM/Gamepad) ]
          |
          v
[ Input Manager ] <--> [ State Machine (Player/Horse) ]
          |
          v
[ Game Loop (RAF) ] --------------------------+
          |                                   |
    [ Logic Update ]                    [ Physics Engine ]
    - Chunk Manager (Streaming)         - Rapier.js (RigidBodies)
    - AI Controller                     - Collision Detection
    - Animation Mixer                   - Projectile Simulation System
          |                                   |
          +-----------------+-----------------+
                            |
                            v
                  [ Three.js Renderer ]
                  - WebGL/WebGPU Pipeline
                  - Post-Processing (Dead-Eye/Bloom)
                  - KTX2/Draco Asset Loader
```

## 3. UI/UX Design Principles
To mirror the "Native-feel" required by the **PRD**, the UI will follow these principles:
- **Minimalist Diegetic UI:** Elements like ammo counts or health should feel integrated or appear only when contextually relevant.
- **Radial Interaction:** As per functional requirement P1, a GSAP-animated radial menu will handle weapon and item selection to maintain flow.
- **Cinematic Framing:** The camera system will use a "Spring Arm" logic to smoothly transition between exploration, horseback riding, and combat.

## 4. Component Architecture
The project will utilize a **Hybrid ECS (Entity-Component-System)** approach to manage the complexity of game objects while maintaining 60FPS performance.

### 4.1. Simulation vs. Rendering (The Bridge)
To avoid React reconciliation bottlenecks during high-frequency updates:
- **Simulation Layer (ECS):** A high-performance ECS library (**bitecs**) manages raw data (position, velocity, health) in TypedArrays. Systems process this data outside of the React render cycle.
- **View Layer (R3F):** React Three Fiber acts as the declarative scene-graph. R3F components "subscribe" to ECS entities, using **Refs** to update Three.js object properties directly (bypass-render) to ensure the "Native-feel" specified in the **PRD**.

### 4.2. The World Manager (Chunking)
As established in **PRD P0**, the World Manager handles seamless loading.
- **Grid-Based Partitioning:** The world is divided into 100x100m chunks.
- **LOD (Level of Detail):** Objects transition from high-poly meshes to billboards based on distance.
- **Worker-Based Loading:** Asset decompression (Draco/Basis) occurs in Web Workers to prevent main-thread jank.

### 4.3. Character & Equine Controllers
- **Unified Controller:** A base class for movement logic, extended for the Player and Horse.
- **Procedural Animation:** Use Three.js `AnimationMixer` with cross-fading for transitions between walk, trot, and gallop.
- **Horse Physics:** The horse acts as a dynamic RigidBody with a floating capsule to handle uneven terrain.

### 4.4. Projectile Simulation & Dead-Eye System
- **Time Dilation:** Implementation of a global `TimeScale` variable. When Dead-Eye is active, `TimeScale` drops to 0.2.
- **Physics Interpolation:** Rapier.js step frequency remains constant, but visual updates are interpolated to maintain smoothness during slow-motion.

### 4.5. AI Architecture & NPC Lifecycle
- **AI Update Loop:** NPC logic and FSM transitions are processed within the ECS at a throttled 20Hz frequency to preserve the main-thread budget for 60FPS rendering.
- **Chunk-Based Lifecycle:** The **Chunk Manager** governs NPC existence. When a chunk is activated, NPCs are instantiated based on the sector's population density map. When a chunk is culled, NPC state is serialized to the ECS data layer, and their Three.js assets are disposed of to prevent memory leaks.

## 5. Data Flow Diagrams
### Asset Loading Flow
1. **Chunk Manager** detects player proximity to a new sector.
2. **Resource Loader** checks cache; if missing, fetches `.glb` (Draco) and `.ktx2` (Basis).
3. **Web Worker** decodes geometry and textures.
4. **Main Thread** instantiates the chunk and adds it to the Three.js `Scene`.

## 6. State Management Design
We will use a **Finite State Machine (FSM)** for the Player and Horse to manage complex transitions:
- **Player States:** `IDLE`, `SPRINT`, `AIM`, `FIRE`, `MOUNTING`, `RIDING`.
- **Horse States:** `STATIONARY`, `CANTER`, `GALLOP`, `REAR_UP`.

The **PRD's** requirement for "Native-feel" input latency is met by processing input at the start of every `requestAnimationFrame` (RAF) before physics steps.

## 7. Error Handling & Edge Cases
- **WebGL Context Loss:** Implement a "Pause & Recover" state to re-initialize buffers without losing player progress.
- **Floating Point Precision:** As noted in the **PRD Risks**, we will implement a **Floating Origin**. When the player moves >5000 units from (0,0,0), the entire world is shifted back to the origin to prevent jitter.
- **Asset Fallback:** If a high-res texture fails to load, a low-res placeholder or "missing texture" material is applied to prevent engine crashes.

## 8. Accessibility Considerations
- **Input Remapping:** A central `InputMap` object that translates raw keys/buttons to game actions.
- **Visual Cues:** Dead-Eye mode will include a high-contrast sepia filter to assist color-blind users in identifying targets.

## 9. Design Decisions & Rationale
| Decision | Rationale | Reference |
| :--- | :--- | :--- |
| **Rapier.js** | Rust-based/WASM physics that is significantly faster than Cannon.js for complex mesh collisions. | PRD Dependencies |
| **Floating Origin** | Prevents the "shaking" effect in 3D rendering when objects are too far from the world center. | PRD Risks |
| **KTX2/Basis** | Essential for the 5MB initial bundle constraint; reduces VRAM usage by up to 75%. | PRD Constraints |
| **GSAP for UI** | Provides the most robust timeline control for the complex P1 "Dead-Eye" UI animations. | PRD Dependencies |
| **Hybrid ECS** | Decouples heavy logic from React's reconciliation to maintain 60FPS in an open world. | Design Doc 4.1 |