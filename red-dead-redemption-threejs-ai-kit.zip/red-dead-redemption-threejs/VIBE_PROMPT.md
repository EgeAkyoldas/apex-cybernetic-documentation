# PROJECT FRONTIER: MASTER AI HANDOFF PROMPT

## 1. PROJECT IDENTITY
- **Name:** Project Frontier
- **Elevator Pitch:** A high-fidelity, browser-based 3D open-world Western action-adventure built on Three.js.
- **Core Problem:** AAA open-world experiences are usually gated by hardware and large installs.
- **Differentiator:** 60 FPS performance in the browser, <5MB initial bundle, and "Native-feel" horse/combat mechanics using a Hybrid ECS architecture.
- **Target Experience:** Exploration, horseback riding, and tactical "Dead-Eye" gunplay.

## 2. DOCUMENT MANIFEST
The following authoritative documents define this system:
1. **PRD:** Defines the 60FPS target, <5MB bundle limit, and core P0 mechanics.
2. **Architecture:** Details the decoupled "Simulation vs. Rendering" C4 model.
3. **Tech Stack:** Mandates Vite, R3F, bitecs (ECS), Rapier.js (WASM Physics), and XState.
4. **Tech Spec:** Defines the 100m chunking system, Floating Origin, and Projectile Simulation.
5. **UI Design:** Establishes the "Survival Cores" HUD and GSAP-driven Radial Menu.
6. **Task List:** A 9-phase implementation roadmap from foundation to launch.
7. **API Spec:** Defines the Supabase persistence layer and Asset Manifest schema.

## 3. TECH STACK SNAPSHOT
- **Engine/View:** Three.js / React Three Fiber (R3F) / Drei
- **Simulation:** bitecs (High-performance ECS using TypedArrays)
- **Physics:** Rapier.js (WASM-based, off-main-thread ready)
- **State:** XState (Behavioral FSMs), Zustand (Transient UI State)
- **Styling/UI:** Tailwind CSS, GSAP (Animations), Lucide React (Icons)
- **Backend:** Supabase (Auth/Postgres), Cloudflare R2 (CDN Assets)

## 4. ARCHITECTURE BRIEF
Project Frontier uses a **Hybrid ECS Architecture**. 
- **The Simulation Core:** `bitecs` manages raw data (Position, Velocity, Stats) in TypedArrays. Systems process this at 60Hz.
- **The View Layer:** `R3F` renders the scene. Components use `useFrame` to sync with ECS data via **Direct Ref Manipulation** (Bypass-Render) to avoid React reconciliation overhead.
- **World Streaming:** A `ChunkManager` loads/unloads 100m x 100m sectors based on player proximity.
- **Floating Origin:** The world shifts back to (0,0,0) when the player exceeds 5000 units to prevent precision jitter.

## 5. CORE DATA MODELS
### ECS Components (bitecs)
- `Transform`: `x, y, z, rx, ry, rz` (f32)
- `Velocity`: `vx, vy, vz` (f32)
- `Stats`: `health, stamina, deadEye` (f32)
- `ActorState`: `stateEnum` (u8 - maps to XState IDs)

### Persistence (Supabase JSON v1.1)
```json
{
  "player_id": "uuid",
  "world_state": {
    "position": [x, y, z],
    "origin_offset": [ox, oy, oz],
    "world_time": 14.5, 
    "active_weather": "clear"
  },
  "horse_state": {
    "spawned": true,
    "position": [hx, hy, hz],
    "is_mounted": false,
    "stamina": 100
  },
  "stats": { "hp": 100, "stamina": 85, "deadeye_meter": 50 },
  "inventory": [
    { "id": "revolver_01", "ammo": 12, "equipped": true }
  ]
}
```

## 6. IMPLEMENTATION ROADMAP (PHASED)
1. **Phase 1: Foundation:** Vite setup + ECS/Physics WASM bridge.
2. **Phase 2: World:** Chunk Manager + Draco/KTX2 Worker pipeline + Floating Origin.
3. **Phase 3: Locomotion:** XState Player FSM + Horse "Floating Capsule" physics.
4. **Phase 4: Combat:** Projectile entities + Dead-Eye (GSAP timeScale lerp).
5. **Phase 5: UI & Persistence:** Survival Cores HUD + Supabase Save/Load.

## 7. DEVELOPMENT RULES
- **Performance First:** All 3D updates MUST happen via Refs in the `useFrame` loop. No React state for 60Hz updates.
- **Bundle Optimization:** `rapier.js` and `xstate` MUST be dynamically imported to stay under the 5MB initial budget.
- **Memory Safety:** Every chunk and asset MUST be explicitly disposed of via `geometry.dispose()` and `texture.dispose()`.
- **Type Safety:** Strict TypeScript for all ECS systems and Bridge logic.
- **Coordinate System:** Y-up, Right-handed.

## 8. FILE STRUCTURE
```text
/src
  /engine
    /ecs          # bitecs World, Components, and Systems
    /physics      # Rapier.js initialization and Workers
    /world        # ChunkManager, WorldShift, and Asset Loaders
  /components
    /render       # R3F Mesh components (Subscribers to ECS)
    /ui           # HUD, Radial Menu, Survival Cores
  /state          # XState machines and Zustand stores
  /hooks          # useBridge (ECS to R3F sync)
  /assets         # Static manifests (GLBs/KTX2s on CDN)
```

## 9. GETTING STARTED
```bash
# Bootstrap the project
npm create vite@latest project-frontier -- --template react-ts
npm install three @types/three @react-three/fiber @react-three/drei
npm install bitecs @dimforge/rapier3d-compat xstate zustand gsap
npm install -D tailwindcss postcss autoprefixer
```

## 10. AI OPERATIONAL INSTRUCTIONS
- You are the Lead Engine Developer for Project Frontier.
- Always prioritize the **Hybrid ECS** pattern over standard React state.
- When writing systems, focus on cache-friendly TypedArray access.
- Refer to the **Tech Spec** for specific math on horse-terrain alignment and projectile raycasting.
- Maintain the "Native-feel" by ensuring input-to-physics latency is minimized.